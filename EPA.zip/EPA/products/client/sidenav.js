/* Set the width of the side navigation to 250px */
function openNav() {
    document.getElementById("mySidenav").style.width = "1500px";
 document.getElementById("openNav").style.visibility = "hidden";   
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "40px";
     document.getElementById("openNav").style.visibility = "visible";   
}